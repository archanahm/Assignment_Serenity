package com.db.am.bauhaus.project;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.steps.Instrumented;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Scroll;
import net.serenitybdd.screenplay.actions.ScrollTo;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;
import static net.serenitybdd.screenplay.questions.WebElementQuestion.the;

/**
 * Created by archanaHM on 06/04/2017.
 */
public class SelectFromIcon implements Task {

    private String searchText;
    private final static List<String> categoryList = Arrays.asList("Home & Living", "Jewellery", "Craft Supplies & Tools", "Weddings","Toys & Games");

    @Step("{0} enters search text #categoryList")
    public <T extends Actor> void performAs(T theUser) {
        theUser.should(
                seeThat("the search input box", the(SearchTarget.INPUT_BOX), isVisible())
        );

/**Scroll is not workig with screenplan action
 theUser.attemptsTo(Scroll.to(By.xpath("//div//h2[contains(text(),'Shop by category')]")),Click.on(Target.the("the all sugessted items table ").located(By.xpath("//div//span//span[contains(text(),'Toys & Games')]")))
**/

             theUser.attemptsTo(Click.on(SearchTarget.PROMOTIONAL_ICON)

        );
        Serenity.setSessionVariable(SessionVar.SEARCH_TEXT).to(searchText);
    }



    public static SelectFromIcon randomText() {
        String selectedText = categoryList.get(new Random().nextInt(categoryList.size()));
        return Instrumented.instanceOf(SelectFromIcon.class).withProperties(selectedText);
    }

    public static SelectFromIcon textCalled(String searchText) {
        return Instrumented.instanceOf(SelectFromIcon.class).withProperties(searchText);
    }

    public SelectFromIcon(String searchText) {
        this.searchText = searchText;
    }

}
