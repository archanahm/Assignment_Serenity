package com.db.am.bauhaus.project.pages;

import com.db.am.bauhaus.project.SearchTarget;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Created by ongshir on 05/10/2016.
 */
@DefaultUrl("/")
public class MainSearchPage extends PageObject {
    String searchText;

    @FindBy(id = "search-query")
    WebElementFacade inputBox;

    @FindBy(css = "button.btn.btn-primary")
    WebElementFacade searchButton;

    @FindBy(xpath = "//div[contains(@class,'fall-cozy-banner-wrapper')]")
    WebElement searchByIcon;

    @FindBy(xpath ="//div[contains(@class,'mt-xs-5')]")
    WebElementFacade searchIconPage;

    public MainSearchPage(WebDriver driver) {
        super(driver);
    }

    public void searchFromInputBox(String searchText) {
        inputBox.waitUntilPresent().sendKeys(searchText);
        searchButton.click();
    }

    public String getTopCategoriesHeader() {
        return find(By.cssSelector("div.pb-xs-1-5")).getText();
    }

    public String getAllCategoriesHeader() {
        return find(By.cssSelector("h1.display-inline.text-smaller")).getText();
    }

        public void selectFromIcon(){
/*        withAction().moveToElement($(".col-xs-12 .mt-xs-3 .mb-xs-3")).click();
          withAction().moveToElement(searchByIcon,450,0).build();*/
        searchByIcon.click();

    }
    public boolean selectFromIconpage(){
        return searchIconPage.isDisplayed();

    }

}
