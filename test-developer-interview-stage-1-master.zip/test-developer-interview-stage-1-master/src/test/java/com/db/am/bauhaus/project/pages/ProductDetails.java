package com.db.am.bauhaus.project.pages;

import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.ResponseBody;

import static net.serenitybdd.rest.SerenityRest.rest;

public class ProductDetails {
    public String getProductResponse(String productType) {
        ResponseBody getProductDetails = rest().given().
                get("").getBody();

        System.out.println(getProductDetails.toString());

        JsonPath jp = new JsonPath(getProductDetails.asString());
        return jp.get("// get the price ").toString();
    }

}