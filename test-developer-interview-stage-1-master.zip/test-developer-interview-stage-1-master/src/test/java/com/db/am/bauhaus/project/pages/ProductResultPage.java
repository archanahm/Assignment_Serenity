package com.db.am.bauhaus.project.pages;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBys;

import org.openqa.selenium.support.ui.Select;

/**
 * Created by ongshir on 05/10/2016.
 */
@DefaultUrl("/")
public class ProductResultPage extends PageObject {


    @FindBy(className = "btn-transaction")
    WebElementFacade cartButton;

    @FindBy(id="listing-body")
    WebElementFacade productdetailspage;

/*    @FindBy(id="listing-body")
    WebElementFacade cartpage;*/

    @FindBy(xpath="//div[contains(@class,'block-grid-xs-3')]/div/a")
    WebElement item;

    @FindBy(xpath = "//div[contains(@class,'multi-shop-cart-col-group')]")
    WebElement cartpage;

    @FindBy(xpath = "//div[contains(@class,'col-group')]/div[contains(@class,'image')]")
    WebElementFacade productInpage;

   //@FindBys(FindBy(xpath = "//div[contains(@class,'col-group')]/div[contains(@class,'image')]"))





    public ProductResultPage(WebDriver driver) {
        super(driver);
    }

    public void selectanyproduct(){
        item.click();

    }


    public boolean produtdeatilspagedispalyed(){

      return  productdetailspage.isDisplayed();
    }


    public void addproductCart() {
        waitFor(cartButton);
        //Select dropdown = new Select();
        cartButton.click();
    }
    public  boolean iscartDisplayed(){
        return cartpage.isDisplayed();

    }
    public boolean productInCart(){
      return  productInpage.isDisplayed();
    }

}
