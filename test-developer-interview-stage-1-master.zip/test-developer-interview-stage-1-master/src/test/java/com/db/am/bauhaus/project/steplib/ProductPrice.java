package com.db.am.bauhaus.project.steplib;




import com.db.am.bauhaus.project.pages.ProductDetails;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Step;
import org.junit.Assert;

public class ProductPrice  {
    public ProductDetails prdPrice = new ProductDetails();

    @Step
    public void getCountryDetails(String prodcatagoery){
        String catagoryName = prdPrice.getProductResponse("dress");

    }

    @Step
    public void assertValues(String expected, String actual) {
        Assert.assertEquals("getprice keymap value of price",actual,expected);
    }

}
