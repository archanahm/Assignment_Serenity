package com.db.am.bauhaus.project.steplib;

import com.db.am.bauhaus.project.pages.MainSearchPage;
import com.db.am.bauhaus.project.pages.ProductResultPage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.WebDriver;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;

/**
 * Created by ongshir on 05/10/2016.
 */
public class SearchUser extends ScenarioSteps {

    MainSearchPage mainSearchPage;
    ProductResultPage productResultPage;

    String searchText = "craft";
    String selectCatgory="Jewellery";

    @Step
    public void search_from_input_box() {
        mainSearchPage.searchFromInputBox(searchText);
    }

    @Step
    public void verify_result_for_top_categories() {
        assertThat(mainSearchPage.getTopCategoriesHeader(), containsString(searchText));
    }

    @Step
    public void verify_result_for_all_categories() {
        assertThat(mainSearchPage.getAllCategoriesHeader(), containsString(searchText));
    }

    @Step
    public void search_from_icon(){
        mainSearchPage.selectFromIcon();
    }
    @Step
    public void verify_select_Catagorypage(){
        mainSearchPage.selectFromIconpage();
    }

    @Step
    public void select_any_item(){

    }
    @Step
    public void adds_Product_to_cart() {
        productResultPage.selectanyproduct();
        if(productResultPage.produtdeatilspagedispalyed()){
            productResultPage.addproductCart();
        }
    }

    @Step
    public void verify_product_inCart(){
        if(productResultPage.iscartDisplayed()){
            productResultPage.productInCart();

        }
    }

}
