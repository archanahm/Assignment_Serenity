package com.db.am.bauhaus.project.steps;

import com.db.am.bauhaus.project.SearchTarget;
import com.db.am.bauhaus.project.SelectFrom;
import com.db.am.bauhaus.project.SelectFromIcon;
import com.db.am.bauhaus.project.SessionVar;
import com.db.am.bauhaus.project.pages.MainSearchPage;
import com.db.am.bauhaus.project.pages.ProductResultPage;
import com.db.am.bauhaus.project.steplib.SearchUser;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.thucydides.core.annotations.Steps;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.containsText;
import static net.serenitybdd.screenplay.questions.WebElementQuestion.the;

/**
 * Created by ongshir on 05/10/2016.
 */
public class BuyingProductSteps {

    @Before
    public void before() {
        OnStage.setTheStage(new OnlineCast());
    }

    @Steps
    SearchUser user;

    MainSearchPage mainSearchPage;
    ProductResultPage productResultPage;


    @Given("^A user is viewing the Etsy landing page$")
    public void goto_landing_page() {
        mainSearchPage.open();
    }

    @Given("^A user searched for product in searchbox$")
    public void a_user_searched_for_product_in_searchbox() {
        user.search_from_input_box();
    }

    @When("^A user adds it to the cart$")
    public void a_user_adds_it_to_the_cart()  {
        user.adds_Product_to_cart();
    }


    @Then("^product should present in the cart$")
    public void product_should_present_in_the_cart()  {
        user.verify_product_inCart();
    }

}
