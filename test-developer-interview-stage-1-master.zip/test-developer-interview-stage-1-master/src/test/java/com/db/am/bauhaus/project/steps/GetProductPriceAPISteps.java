package com.db.am.bauhaus.project.steps;

import com.db.am.bauhaus.project.steplib.ProductPrice;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
/**
 * Created by ArchanaHM on 08/11/2017.
 */
public class GetProductPriceAPISteps {

    @Before
    public void before() {
        OnStage.setTheStage(new OnlineCast());
    }


    @Steps
    ProductPrice productPrice;



    @When("^he searches for a product from the input box$")
    public void i_retrieve_a_booking() throws Throwable {
        productPrice.getCountryDetails("dress");
    }

    @Then("^i should be able to see the product price$")
    public void i_should_be_able_to_see_the_details() throws Throwable {
        productPrice.assertValues("get the value from db ","compare the one got from the response");
    }


}


